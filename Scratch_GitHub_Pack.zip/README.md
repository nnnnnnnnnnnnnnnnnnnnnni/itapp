# Scratch Quiz Game (Progress Review)

**Built in:** Scratch  
**Core flow:** Quiz → (Correct: +POINTS & continue) / (Wrong: Try Again & restart) → Win Screen → Home or Play Again

## What this repo is for
Scratch projects are saved as a single `.sb3` file, so GitHub is used mainly for:
- **Planning** (Issues + Project board)
- **Evidence** (screenshots of UI + code blocks)
- **Backups** (versioned `.sb3` uploads at milestones)

## Files to add
1. Put your Scratch file here: `scratch_project/your_project.sb3`
2. Add screenshots here: `screenshots/`
   - quiz screen
   - try again screen
   - win screen
   - key code blocks (broadcast + points)

## Quick demo checklist (for presentation)
See: `docs/testing_checklist.md`

_Last updated: 2026-02-05_
