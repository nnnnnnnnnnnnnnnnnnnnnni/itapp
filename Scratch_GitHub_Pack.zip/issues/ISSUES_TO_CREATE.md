# Issues to Create (Copy/Paste)

Create these issues in GitHub (Issues → New Issue). Keep them short and move them across your Project board.

## Core Build
1) **Set up quiz screen (show/hide answer buttons)**
   - Ensure buttons only show during the quiz section.
   - Evidence: screenshot of quiz screen + code blocks.

2) **Correct answer logic (broadcast + add POINTS)**
   - On click: broadcast "Correct", change POINTS by +1, continue flow.

3) **Wrong answer logic (broadcast WRONG)**
   - On click: broadcast "Wrong" and route to Try Again screen.

4) **Try Again screen (switch backdrop + restart game flow)**
   - Show Try Again message then restart the game cleanly.

5) **Win screen UI (show buttons when completed)**
   - Win screen appears only when completion condition is met.

6) **Home button (homepage broadcast + switch backdrop + hide UI)**
   - Return to homepage and hide win UI buttons.

7) **Play Again button (start broadcast + reset state)**
   - Restart game flow and reset variables/UI if needed.

8) **Integrate full flow end-to-end**
   - Quiz → Try Again/restart OR continue → completion → Win screen → Home/Play Again.

## Testing
9) **Test: correct answer increases POINTS**
10) **Test: wrong answer goes Try Again + restarts**
11) **Test: win screen triggers correctly**
12) **Test: Home and Play Again navigation works**

## Polish
13) **UI consistency cleanup (positions, hide/show, no overlap)**
14) **Prepare presentation backup screenshots**
