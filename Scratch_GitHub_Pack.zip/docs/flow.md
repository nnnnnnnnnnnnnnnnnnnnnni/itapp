# App Flow (Scratch)

## Quiz
- Buttons are hidden by default.
- When quiz starts, buttons show (by broadcast / state).
- **Correct click:**
  - broadcast "Correct"
  - change variable POINTS by +1
  - continue to next part
- **Wrong click:**
  - broadcast "Wrong"
  - go to Try Again screen
  - restart game flow

## Win Screen
- Triggered when completion condition is met.
- **Home button:** broadcast "homepage" → switch to homepage backdrop → hide win UI
- **Play Again:** broadcast "start" → switch to main/start backdrop → hide win UI → reset variables/state as needed
