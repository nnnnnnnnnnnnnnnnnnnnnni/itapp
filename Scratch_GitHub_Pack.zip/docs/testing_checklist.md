# Testing Checklist (Quick)

## Quiz
- [ ] Answer buttons only appear during quiz (not random screens)
- [ ] Correct answer increases POINTS by 1
- [ ] Correct answer continues the game flow
- [ ] Wrong answer goes to Try Again screen
- [ ] Try Again restarts the game properly (no leftover UI)

## Win Screen
- [ ] Win screen appears only when all required parts are completed
- [ ] Home button returns to homepage and hides win UI
- [ ] Play Again returns to start/map and resets state

## UI
- [ ] Buttons are consistent (position, size, clear labels)
- [ ] No overlapping sprites/buttons between screens
