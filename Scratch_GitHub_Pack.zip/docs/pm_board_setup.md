# GitHub Planning Setup (for Lecturer Evidence)

## Project Board Columns
Create a GitHub Projects **Board** with these columns:
- Backlog
- To do
- In progress
- Testing
- Done

## How to use
- Create Issues for each feature/test task (see `issues/ISSUES_TO_CREATE.md`)
- Add Issues to the board and drag them across columns as you work
- Attach screenshots to Issues to prove progress
- Upload new `.sb3` versions at milestones (MVP, Final)
