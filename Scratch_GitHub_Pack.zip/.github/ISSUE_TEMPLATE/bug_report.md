---
name: Bug report
about: Something is not working
title: "[Bug] "
labels: bug
assignees: ''
---

## What happened
- 

## Expected
- 

## Evidence
- Screenshot / steps
