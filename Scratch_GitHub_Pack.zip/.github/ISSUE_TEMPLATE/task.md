---
name: Task
about: Small task / checklist item
title: "[Task] "
labels: task
assignees: ''
---

## Task
- 

## Evidence
- Screenshot / note
